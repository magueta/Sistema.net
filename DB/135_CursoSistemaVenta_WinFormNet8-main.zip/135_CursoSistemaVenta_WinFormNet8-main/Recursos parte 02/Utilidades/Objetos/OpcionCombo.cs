﻿

namespace SVPresentation.Utilidades.Objetos
{
    public class OpcionCombo
    {
        public string Texto { get; set; }
        public int Valor { get; set; }
    }
}
